<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.18
    </div>
    <strong>Copyright &copy; 2021 <a href="https://adminlte.io">Free Activity</a>.</strong> All rights
    reserved.
  </footer>